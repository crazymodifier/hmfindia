<main>
	<section class="pt-4 my-5">
		<div class="container">
			<div class="heading pb-4 text-center">
				<h2><span>About helios multizone foundation</span></h2>
			</div>
			<div class="row">
				<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
					<img src="<?=base_url('assets/images/brochure-1b.jpg')?>" class="w-100" alt="">
				</div>
				<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
					<img src="<?=base_url('assets/images/brochure-1.jpg')?>" class="w-100" alt="">
				</div>
			</div>
		</div>
	</section>

	<section class="fixed-bg " style="background-image: url(./assets/images/slider1.jpg);">
		<div class="pt-5 opacity-7">
			<div class="container">
				<div class="row pb-4 mission-slider">
					<div class="p-4">
						<div>
							<div class="card top shadow pop">
								<div class="card-body">
									<p>The mission of the Foundation is to provide quality public services in a timely and competent manner, and to work with the cooperation of the community and other local government units to create a vibrant and healthy physical, social and economic environment. Services shall be provided in a fair, respectful and professional manner consistent with available human, natural and economic resources.</p>
								</div>
							</div>
							<div class="text-center mt-5">
								<img src="<?=base_url('assets/images/mission.png')?>" class="w-50 bg-light rounded-circle m-auto" alt="">
								<h2 class="text-light">Our Mision</h2>
							</div>
						</div>
					</div>
					<div class="p-4">
						<div>

							<div class="text-center mb-5">
								<h2 class="text-light">Our Vision</h2>
								<img src="<?=base_url('assets/images/hmfindia-policy.png')?>" class="w-50 bg-light rounded-circle m-auto" alt="">
							</div>
							<div class="card bottom shadow pop">
								<div class="pt-5 card-body">
									<p>Go into the places only locals are familiar with. Visit little known hideouts and avenues that open the mind into what being a local is all about.</p>
								</div>
							</div>
						</div>
					</div>
					<div class="p-4">
						<div>
							<div class="card top shadow pop">
								<div class="card-body">
									<p>Our local government will be nationally known for its transformative efforts that make the Foundation the diverse and sustainable community of choice for people to live, work, and play as a result of its safety; vibrant neighborhoods; business, educational, and cultural opportunities; connectedness; and vitality.</p>
								</div>
							</div>
							<div class="text-center mt-5">
								<img src="<?=base_url('assets/images/hmfindia-vision.jpg')?>" class="w-50 bg-light rounded-circle m-auto" alt="">
								<h2 class="text-light">Our Vision</h2>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="py-5">
		<div class="container">
			<div class="heading pb-3">
				<h2 class="mb-4 text-center"><span>Certificates</span></h2>
				<div class="divider"><span></span></div>
			</div>
			<div class="row">
				<div class="col-xl-4 col-lg-4 col-md-4 p-4">
					<img src="<?=base_url('assets/images/hmfindia-pan.jpg')?>" alt="HMF India PAN" class="w-100 card shadow">
				</div>
				<div class="col-xl-4 col-lg-4 col-md-4 p-4">
					<img src="<?=base_url('assets/images/certificate.jpg')?>" alt="Certificate" class="w-100 card shadow">
				</div>
				<div class="col-xl-4 col-lg-4 col-md-4 p-4">
					<img src="<?=base_url('assets/images/companies-act.jpg')?>" alt="Companies Act" class="w-100 card shadow">
				</div>
			</div>
		</div>
	</section>
</main>