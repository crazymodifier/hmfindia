
<!-- Button to Open the Modal -->
<button type="button" id="query_btn" class="btn btn-danger" data-toggle="modal" data-target="#query_form">
  Ask your
  Query
</button>
<a id="whatsapp" href="https://api.whatsapp.com/send?phone=+917236098508&text=type your massege here.."><img width="50" src="<?=base_url()?>assets/images/whatsapp.png"></a>
<!-- The Modal -->
<div class="modal fade" id="query_form">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header border-0">
        <h4 class="modal-title">Query form</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <form action="<?=base_url('Welcome/query')?>" method="POST">
      <!-- Modal body -->
      <div class="modal-body px-4">
        <div class="form-group">
          <input type="text" name="name" class="form-control" placeholder="Enter your name">
        </div>
        <div class="form-group">
          <input type="number" name="mobile" class="form-control" placeholder="Enter your contact number">
        </div>
        <div class="form-group">
          <input type="email" name="email" class="form-control" placeholder="Enter your email">
        </div>
        <div class="form-group">
          <textarea name="message" class="form-control" placeholder="Enter your qurey"></textarea>
        </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer border-0">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button class="btn btn-primary">Submit</button>
      </div>
      </form>
    </div>
  </div>
</div>
<footer>

    <section class="bg-dark text-light py-2">
        <div class="d-flex container justify-content-between">
            <span>
                &copy; 2019 - <?= date("Y");?> All Rights Resevred. | Digital Partner : <a class="text-light" href="https:kumaardigitalworld.com"> Kumaar Digital World</a> 
            </span>
            <span>
                Developed By : <a class="text-light" href="https:crazymodifier.com"> Crazy Modifier</a>
            </span>
        </div>
    </section>
</footer>
<script>
// Sticky navbar
// =========================
            $(document).ready(function () {
$('.donate-slider').slick({
      slidesToShow: 4,
      centerMode: false,
      centerPadding: '00px',
      mobileFirst:true,
      responsive: [
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 4,
            slidesToScroll: 1,
            infinite: true,
            autoplay:true,
            speed:2000,
            arrows:false,
          }
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            infinite: true,
            autoplay:true,
            speed:2000,
            arrows:false,
          }
        },
        {
          breakpoint: 500,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            autoplay:true,
            speed:2000,
            arrows:false,
          }
        },
        {
          breakpoint: 300,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay:true,
            speed:2000,
            arrows:false,
          }
        }
        ],
      });
$('.mission-slider').slick({
      slidesToShow: 3,
      centerMode: false,
      centerPadding: '00px',
      mobileFirst:true,
      responsive: [
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            infinite: true,
            autoplay:true,
            speed:2000,
            arrows:false,
          }
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            infinite: true,
            autoplay:true,
            speed:2000,
            arrows:false,
          }
        },
        {
          breakpoint: 500,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows:false,
            autoplay:true,
            speed:2000,
          }
        },
        {
          breakpoint: 300,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay:true,
            arrows:false,
            speed:2000,
          }
        }
        ],
      });

$('.slider-5').slick({
    slidesToShow:5, 
    autoplay:true,
    speed:1500,
})
                // Custom function which toggles between sticky class (is-sticky)
                var stickyToggle = function (sticky, stickyWrapper, scrollElement) {
                    var stickyHeight = sticky.outerHeight();
                    var stickyTop = stickyWrapper.offset().top;
                    if (scrollElement.scrollTop() >= stickyTop) {
                        stickyWrapper.height(stickyHeight);
                        sticky.addClass("is-sticky");
                    }
                    else {
                        sticky.removeClass("is-sticky");
                        stickyWrapper.height('auto');
                    }
                };

                // Find all data-toggle="sticky-onscroll" elements
                $('[data-toggle="sticky-onscroll"]').each(function () {
                    var sticky = $(this);
                    var stickyWrapper = $('<div>').addClass('sticky-wrapper'); // insert hidden element to maintain actual top offset on page
                    sticky.before(stickyWrapper);
                    sticky.addClass('sticky');

                    // Scroll & resize events
                    $(window).on('scroll.sticky-onscroll resize.sticky-onscroll', function () {
                        stickyToggle(sticky, stickyWrapper, $(this));
                    });

                    // On page load
                    stickyToggle(sticky, stickyWrapper, $(window));
                });
                $("#signin").click(function(){
        $(".left-side").addClass("left-40");
        $(".hiddenn").css({"opacity": "1", "z-index": "1"});
        $(".visible").css({"opacity": "0", "z-index": "-1"});
        $(".right-side").addClass("right-60");
    })
    $("#signup").click(function(){
        $(".left-side").removeClass("left-40");
        $(".hiddenn").css({"opacity": "0", "z-index": "-1"});
        $(".visible").css({"opacity": "1", "z-index": "1"});
        $(".right-side").removeClass("right-60");
    })
            });
</script>
</body>
</html>